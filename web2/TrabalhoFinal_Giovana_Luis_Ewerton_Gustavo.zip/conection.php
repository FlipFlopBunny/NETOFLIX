<?php

$hostname = 'localhost';
$username = 'root';
$passworrd = '';
$database = 'cinedb';

$conn = mysqli_connect($hostname, $username, $passworrd, $database);
if (mysqli_connect_error()) {
    echo 'Erro de conexão fale com o administrador: ' . mysqli_connect_error();
}
?>